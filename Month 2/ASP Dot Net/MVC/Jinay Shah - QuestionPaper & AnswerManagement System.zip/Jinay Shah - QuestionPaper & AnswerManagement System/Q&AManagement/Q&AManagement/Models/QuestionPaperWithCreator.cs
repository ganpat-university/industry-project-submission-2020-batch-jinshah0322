﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Q_AManagement.Models
{
    public class QuestionPaperWithCreator
    {
        public QuestionPaper QuestionPaper { get; set; }
        public string CreatorName { get; set; }
    }
}