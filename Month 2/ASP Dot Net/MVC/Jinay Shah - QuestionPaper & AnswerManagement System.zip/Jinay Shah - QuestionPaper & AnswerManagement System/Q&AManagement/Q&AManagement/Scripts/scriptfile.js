﻿$(document).ready(function () {
    $('.displayMessage').fadeOut(1750);
});